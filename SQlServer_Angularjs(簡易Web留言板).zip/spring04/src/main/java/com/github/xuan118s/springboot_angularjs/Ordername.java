package com.github.xuan118s.springboot_angularjs;
import java.util.Date;

public class Ordername {

	public String username;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	} 
	    
	

}
